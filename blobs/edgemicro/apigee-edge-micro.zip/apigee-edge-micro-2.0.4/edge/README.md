#edge dependency directories
these files are for the cli configure command
they are deployed to create the edge-auth proxy